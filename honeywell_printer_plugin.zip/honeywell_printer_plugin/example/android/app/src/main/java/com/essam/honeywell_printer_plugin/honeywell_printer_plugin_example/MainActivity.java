package com.essam.honeywell_printer_plugin.honeywell_printer_plugin_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
