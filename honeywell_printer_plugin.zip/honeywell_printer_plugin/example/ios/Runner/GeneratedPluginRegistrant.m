//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<honeywell_printer_plugin/HoneywellPrinterPlugin.h>)
#import <honeywell_printer_plugin/HoneywellPrinterPlugin.h>
#else
@import honeywell_printer_plugin;
#endif

#if __has_include(<firebase_core/FLTFirebaseCorePlugin.h>)
#import <firebase_core/FLTFirebaseCorePlugin.h>
#else
@import firebase_core;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [HoneywellPrinterPlugin registerWithRegistrar:[registry registrarForPlugin:@"HoneywellPrinterPlugin"]];
  [FLTFirebaseCorePlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTFirebaseCorePlugin"]];
}

@end
